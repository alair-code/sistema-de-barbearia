/* ==========================================================================
   BarberFlow — Sistema de Gestão para Barbearias
   Arquivo: js/script.js

   IMPORTANTE: este arquivo deve ser carregado como script comum (sem
   type="module"), pois o HTML gerado usa atributos onclick/onsubmit que
   chamam as funções globais abaixo.

   ÍNDICE
   01. Camada de dados (LocalStorage, dados padrão, utilitários)
   02. Configuração da navegação
   03. Funções de renderização de páginas
       03.1 Dashboard
       03.2 Agenda
       03.3 Agendamento
       03.4 Clientes
       03.5 Serviços
       03.6 Retenção
       03.7 Financeiro
       03.8 Site da Barbearia
       03.9 Relatórios
       03.10 Configurações
   04. Sistema de modal
   05. Formulários (cliente, serviço, barbeiro, agendamento, bloqueio)
   06. Exportar / importar / resetar dados
   07. Navegação
   08. Eventos (delegação de cliques)
   09. Inicialização
   ========================================================================== */


/* ==========================================================================
   01. CAMADA DE DADOS
   ========================================================================== */

// Chave usada para guardar tudo no LocalStorage do navegador
const STORAGE_KEY = 'barberflow_data';

/**
 * Retorna os dados iniciais (de exemplo) do sistema.
 * Usado no primeiro acesso e quando o usuário reseta os dados.
 */
function getDefaultData() {
    return {
        // Barbeiros da equipe
        barbers: [
            { id: 'b1', nome: 'Carlos Silva', foto: 'https://picsum.photos/200?random=101', ativo: true },
            { id: 'b2', nome: 'Rafael Oliveira', foto: 'https://picsum.photos/200?random=102', ativo: true },
            { id: 'b3', nome: 'Lucas Santos', foto: 'https://picsum.photos/200?random=103', ativo: true }
        ],

        // Serviços oferecidos (preço em R$, duração em minutos)
        services: [
            { id: 's1', nome: 'Corte Masculino', preco: 45, duracao: 40, descricao: 'Corte com tesoura e máquina, finalização com produtos.', ativo: true },
            { id: 's2', nome: 'Barba Completa', preco: 35, duracao: 30, descricao: 'Aparar e modelar barba com navalha e pós-barba.', ativo: true },
            { id: 's3', nome: 'Corte + Barba', preco: 70, duracao: 60, descricao: 'Combo completo de corte e barba com finalização.', ativo: true },
            { id: 's4', nome: 'Hidratação Capilar', preco: 55, duracao: 45, descricao: 'Hidratação profunda com queratina e óleos essenciais.', ativo: true },
            { id: 's5', nome: 'Sobrancelha', preco: 20, duracao: 15, descricao: 'Design de sobrancelha com pinça e navalha.', ativo: true }
        ],

        // Clientes cadastrados
        clients: [
            { id: 'c1', nome: 'João Pereira', telefone: '(11) 99999-0001', email: 'joao@email.com', dataCadastro: '2025-01-10', ultimaVisita: '2025-06-15', observacoes: 'Preferência por degradê suave', ativo: true, preferencias: 'Degradê, pomba fixação forte' },
            { id: 'c2', nome: 'Márcio Andrade', telefone: '(11) 99999-0002', email: 'marcio@email.com', dataCadastro: '2025-02-05', ultimaVisita: '2025-06-10', observacoes: 'Alérgico a certos produtos', ativo: true, preferencias: 'Barba cheia' },
            { id: 'c3', nome: 'Felipe Costa', telefone: '(11) 99999-0003', email: 'felipe@email.com', dataCadastro: '2025-03-12', ultimaVisita: '2025-06-01', observacoes: '', ativo: true, preferencias: 'Corte social' },
            { id: 'c4', nome: 'Thiago Martins', telefone: '(11) 99999-0004', email: 'thiago@email.com', dataCadastro: '2025-01-20', ultimaVisita: '2025-04-05', observacoes: 'Cliente sazonal', ativo: true, preferencias: 'Degradê militar' },
            { id: 'c5', nome: 'Gabriel Souza', telefone: '(11) 99999-0005', email: 'gabriel@email.com', dataCadastro: '2024-11-15', ultimaVisita: '2025-02-20', observacoes: 'Não compareceu a 2 agendamentos', ativo: false, preferencias: '' },
            { id: 'c6', nome: 'André Lima', telefone: '(11) 99999-0006', email: 'andre@email.com', dataCadastro: '2025-04-01', ultimaVisita: '2025-06-18', observacoes: '', ativo: true, preferencias: 'Corte texturizado' }
        ],

        // Agendamentos (status: agendado | confirmado | finalizado | cancelado)
        appointments: [
            { id: 'a1', clienteId: 'c1', servicoId: 's3', barbeiroId: 'b1', data: '2025-06-20', hora: '09:00', status: 'confirmado', valor: 70, formaPagamento: 'pix', observacoes: '' },
            { id: 'a2', clienteId: 'c2', servicoId: 's1', barbeiroId: 'b2', data: '2025-06-20', hora: '10:00', status: 'confirmado', valor: 45, formaPagamento: 'dinheiro', observacoes: '' },
            { id: 'a3', clienteId: 'c3', servicoId: 's2', barbeiroId: 'b3', data: '2025-06-20', hora: '11:00', status: 'confirmado', valor: 35, formaPagamento: 'credito', observacoes: 'Barba cheia' },
            { id: 'a4', clienteId: 'c4', servicoId: 's5', barbeiroId: 'b1', data: '2025-06-20', hora: '14:00', status: 'confirmado', valor: 20, formaPagamento: 'pix', observacoes: '' },
            { id: 'a5', clienteId: 'c6', servicoId: 's4', barbeiroId: 'b2', data: '2025-06-21', hora: '09:30', status: 'agendado', valor: 55, formaPagamento: 'debito', observacoes: '' },
            { id: 'a6', clienteId: 'c1', servicoId: 's1', barbeiroId: 'b3', data: '2025-06-22', hora: '15:00', status: 'agendado', valor: 45, formaPagamento: 'pix', observacoes: '' },
            { id: 'a7', clienteId: 'c5', servicoId: 's3', barbeiroId: 'b1', data: '2025-06-18', hora: '10:00', status: 'cancelado', valor: 70, formaPagamento: 'pix', observacoes: 'Cliente cancelou por emergência' },
            { id: 'a8', clienteId: 'c2', servicoId: 's1', barbeiroId: 'b2', data: '2025-06-19', hora: '16:00', status: 'finalizado', valor: 45, formaPagamento: 'dinheiro', observacoes: '' },
            { id: 'a9', clienteId: 'c3', servicoId: 's3', barbeiroId: 'b1', data: '2025-06-19', hora: '11:00', status: 'finalizado', valor: 70, formaPagamento: 'credito', observacoes: '' },
            { id: 'a10', clienteId: 'c4', servicoId: 's2', barbeiroId: 'b3', data: '2025-06-17', hora: '13:00', status: 'finalizado', valor: 35, formaPagamento: 'pix', observacoes: '' }
        ],

        // Pagamentos registrados
        payments: [
            { id: 'p1', appointmentId: 'a8', valor: 45, formaPagamento: 'dinheiro', data: '2025-06-19', status: 'confirmado' },
            { id: 'p2', appointmentId: 'a9', valor: 70, formaPagamento: 'credito', data: '2025-06-19', status: 'confirmado' },
            { id: 'p3', appointmentId: 'a10', valor: 35, formaPagamento: 'pix', data: '2025-06-17', status: 'confirmado' }
        ],

        // Configurações gerais
        settings: {
            // Horário de funcionamento
            workingHours: {
                dias: ['seg', 'ter', 'qua', 'qui', 'sex', 'sab'],
                horarioInicio: '08:00',
                horarioFim: '19:00',
                intervaloDuracao: 30
            },
            // Horários bloqueados (folgas, reuniões, etc.)
            blockedTimes: [],
            // Dados da barbearia (aparecem no "Site da Barbearia")
            barberShop: {
                nome: 'BarberFlow Studio',
                logo: '',
                endereco: 'Rua das Barbearias, 123 - Centro',
                telefone: '(11) 3000-0000',
                whatsapp: '5511999999999',
                instagram: '@barberflow_studio',
                descricao: 'Tradição e estilo se encontram na sua barbearia de confiança.',
                sobre: 'Há mais de 10 anos transformando o visual dos nossos clientes com expertise e dedicação.'
            }
        },

        // Lista de espera
        waitlist: [
            { id: 'w1', clienteId: 'c5', servicoId: 's1', dataSolicitacao: '2025-06-19', observacoes: 'Qualquer horário' }
        ],

        // Histórico de cancelamentos
        cancellations: [
            { id: 'x1', appointmentId: 'a7', motivo: 'Cliente cancelou por emergência', data: '2025-06-18', por: 'cliente' }
        ]
    };
}

// Banco de dados em memória (carregado do LocalStorage ao abrir o sistema)
let DB = loadData();

/**
 * Carrega os dados do LocalStorage.
 * Se algum bloco estiver faltando, completa com os dados padrão.
 */
function loadData() {
    try {
        const raw = localStorage.getItem(STORAGE_KEY);
        if (raw) {
            const parsed = JSON.parse(raw);
            // Mescla com os padrões para garantir que todas as chaves existam
            const def = getDefaultData();
            for (let key of Object.keys(def)) {
                if (!parsed[key]) parsed[key] = def[key];
            }
            return parsed;
        }
    } catch (e) { console.warn('Erro ao carregar dados:', e); }
    return getDefaultData();
}

/** Salva o banco de dados atual no LocalStorage. */
function saveData() {
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(DB));
    } catch (e) { console.warn('Erro ao salvar dados:', e); }
}

/** Gera um ID único (data/hora + parte aleatória). */
function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2, 6);
}

/** Retorna a data de hoje no formato AAAA-MM-DD. */
function today() {
    return new Date().toISOString().split('T')[0];
}

/** Converte AAAA-MM-DD para o formato brasileiro DD/MM/AAAA. */
function formatDate(dateStr) {
    const d = new Date(dateStr + 'T12:00:00');
    return d.toLocaleDateString('pt-BR', { timeZone: 'UTC' });
}

/** Formata um número como moeda: R$ 45,00 */
function formatCurrency(val) {
    return 'R$ ' + val.toFixed(2).replace('.', ',');
}

// ----- Buscas por ID -----
function getClient(id) {
    return DB.clients.find(c => c.id === id);
}

function getService(id) {
    return DB.services.find(s => s.id === id);
}

function getBarber(id) {
    return DB.barbers.find(b => b.id === id);
}

/** Retorna todos os agendamentos de uma data (AAAA-MM-DD). */
function getAppointmentsByDate(date) {
    return DB.appointments.filter(a => a.data === date);
}

/** Converte a sigla do dia ('seg', 'ter'...) no número do dia da semana (0 a 6). */
function getDayName(pt) {
    const map = { 'dom': 0, 'seg': 1, 'ter': 2, 'qua': 3, 'qui': 4, 'sex': 5, 'sab': 6 };
    return map[pt] !== undefined ? map[pt] : -1;
}

/** Verifica se a barbearia funciona na data informada. */
function isWorkingDay(date) {
    const d = new Date(date + 'T12:00:00');
    const day = d.getDay();
    const names = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab'];
    return DB.settings.workingHours.dias.includes(names[day]);
}

/** Retorna uma lista com as próximas N datas, a partir de hoje. */
function getNextDays(count) {
    const result = [];
    for (let i = 0; i < count; i++) {
        const d = new Date();
        d.setDate(d.getDate() + i);
        result.push(d.toISOString().split('T')[0]);
    }
    return result;
}

/**
 * Exibe uma notificação (toast) no canto da tela.
 * @param {string} message - texto da mensagem
 * @param {string} type - 'success' | 'error' | 'info' | 'warning'
 */
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = 'toast ' + type;
    toast.textContent = message;
    container.appendChild(toast);
    // Some depois de 3,5 segundos
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}


/* ==========================================================================
   02. CONFIGURAÇÃO DA NAVEGAÇÃO
   Para adicionar uma nova página: inclua um item aqui, crie a função
   renderXxx() e registre-a em renderPage().
   ========================================================================== */

const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'fa-chart-pie' },
    { id: 'agenda', label: 'Agenda', icon: 'fa-calendar-alt' },
    { id: 'agendamento', label: 'Agendamento', icon: 'fa-calendar-check' },
    { id: 'clientes', label: 'Clientes', icon: 'fa-users' },
    { id: 'servicos', label: 'Serviços', icon: 'fa-cut' },
    { id: 'retencao', label: 'Retenção', icon: 'fa-user-clock' },
    { id: 'financeiro', label: 'Financeiro', icon: 'fa-coins' },
    { id: 'site', label: 'Site da Barbearia', icon: 'fa-globe' },
    { id: 'relatorios', label: 'Relatórios', icon: 'fa-chart-line' },
    { id: 'configuracoes', label: 'Configurações', icon: 'fa-cog' }
];

// Página atualmente exibida
let currentPage = 'dashboard';


/* ==========================================================================
   03. FUNÇÕES DE RENDERIZAÇÃO DE PÁGINAS
   ========================================================================== */

/** Gera o HTML dos itens do menu lateral. */
function renderNav() {
    return navItems.map(item => `
        <a class="nav-item ${currentPage === item.id ? 'active' : ''}" data-nav="${item.id}">
            <i class="fas ${item.icon}"></i>
            <span>${item.label}</span>
        </a>
    `).join('');
}

/** Desenha a página escolhida dentro do container principal. */
function renderPage(pageId) {
    const container = document.getElementById('pagesContainer');
    const pages = {
        dashboard: renderDashboard(),
        agenda: renderAgenda(),
        agendamento: renderAgendamento(),
        clientes: renderClientes(),
        servicos: renderServicos(),
        retencao: renderRetencao(),
        financeiro: renderFinanceiro(),
        site: renderSite(),
        relatorios: renderRelatorios(),
        configuracoes: renderConfiguracoes()
    };
    container.innerHTML = pages[pageId] || '<p>Página não encontrada.</p>';

    // Atualiza o título no topo
    const nav = navItems.find(n => n.id === pageId);
    document.getElementById('pageTitle').textContent = nav ? nav.label : 'BarberFlow';

    // Executa ações extras após desenhar a página
    if (pageId === 'dashboard') postRenderDashboard();
    if (pageId === 'agenda') postRenderAgenda();
    if (pageId === 'agendamento') postRenderAgendamento();
    if (pageId === 'financeiro') postRenderFinanceiro();
    if (pageId === 'relatorios') postRenderRelatorios();
}


/* --------------------------------------------------------------------------
   03.1 DASHBOARD
   Resumo do dia: indicadores, agenda de hoje, alertas e próximos agendamentos.
   -------------------------------------------------------------------------- */

function renderDashboard() {
    const hoje = today();
    const apptsHoje = getAppointmentsByDate(hoje).filter(a => a.status !== 'cancelado');
    const confirmados = apptsHoje.filter(a => a.status === 'confirmado' || a.status === 'agendado');
    const finalizadosHoje = apptsHoje.filter(a => a.status === 'finalizado');
    const faturamentoHoje = finalizadosHoje.reduce((s, a) => s + a.valor, 0);
    const totalAppts = DB.appointments.length;
    const cancelados = DB.appointments.filter(a => a.status === 'cancelado').length;
    const clientesAtivos = DB.clients.filter(c => c.ativo).length;

    // Alertas: clientes com mais de 60 dias sem visita
    const alertas = [];
    DB.clients.forEach(c => {
        if (!c.ultimaVisita) return;
        const dias = Math.floor((new Date() - new Date(c.ultimaVisita + 'T12:00:00')) / (1000 * 60 * 60 * 24));
        if (dias > 60 && c.ativo) {
            alertas.push({ tipo: 'ausente', cliente: c, dias });
        }
    });

    // Cancelamentos dos últimos 7 dias
    const cancRecent = DB.cancellations.filter(x => {
        const diff = Math.floor((new Date() - new Date(x.data + 'T12:00:00')) / (1000 * 60 * 60 * 24));
        return diff <= 7;
    });

    return `
        <div class="space-y-6">
            <!-- Indicadores -->
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="card">
                    <p class="text-[var(--text-muted)] text-sm">Agendamentos Hoje</p>
                    <p class="text-3xl font-bold mt-1">${confirmados.length}</p>
                    <p class="text-xs text-[var(--text-muted)] mt-1">${finalizadosHoje.length} finalizados</p>
                </div>
                <div class="card">
                    <p class="text-[var(--text-muted)] text-sm">Faturamento Hoje</p>
                    <p class="text-3xl font-bold mt-1 text-[var(--primary-light)]">${formatCurrency(faturamentoHoje)}</p>
                    <p class="text-xs text-[var(--text-muted)] mt-1">${finalizadosHoje.length} atendimentos</p>
                </div>
                <div class="card">
                    <p class="text-[var(--text-muted)] text-sm">Clientes Ativos</p>
                    <p class="text-3xl font-bold mt-1">${clientesAtivos}</p>
                    <p class="text-xs text-[var(--text-muted)] mt-1">${DB.clients.length} total</p>
                </div>
                <div class="card">
                    <p class="text-[var(--text-muted)] text-sm">Cancelamentos (7d)</p>
                    <p class="text-3xl font-bold mt-1 ${cancRecent.length > 0 ? 'text-[var(--danger)]' : ''}">${cancRecent.length}</p>
                    <p class="text-xs text-[var(--text-muted)] mt-1">${cancelados} total no período</p>
                </div>
            </div>

            <!-- Timeline do dia -->
            <div class="card">
                <div class="flex items-center justify-between mb-4">
                    <h3 class="font-semibold text-lg">Agenda de Hoje</h3>
                    <span class="text-sm text-[var(--text-muted)]">${formatDate(hoje)}</span>
                </div>
                ${confirmados.length === 0 ? `
                <div class="py-8 text-center text-[var(--text-muted)]">
                    <i class="fas fa-calendar-day text-3xl mb-2"></i>
                    <p>Nenhum agendamento para hoje.</p>
                </div>
                ` : `
                <div class="timeline space-y-0">
                    ${confirmados.sort((a, b) => a.hora.localeCompare(b.hora)).map(a => {
                        const cl = getClient(a.clienteId);
                        const sv = getService(a.servicoId);
                        const br = getBarber(a.barbeiroId);
                        return `
                        <div class="timeline-item">
                            <span class="time">${a.hora}</span>
                            <div>
                                <p class="font-medium">${cl ? cl.nome : 'Cliente removido'}</p>
                                <p class="text-sm text-[var(--text-secondary)]">${sv ? sv.nome : ''} · ${br ? br.nome : ''}</p>
                                <p class="text-sm text-[var(--text-muted)]">${formatCurrency(a.valor)} · <span class="badge ${a.status === 'confirmado' ? 'badge-success' : 'badge-info'}">${a.status}</span></p>
                            </div>
                        </div>
                        `;
                    }).join('')}
                </div>
                `}
            </div>

            <!-- Alertas e próximos agendamentos -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div class="card">
                    <h3 class="font-semibold text-lg mb-3 flex items-center gap-2">
                        <i class="fas fa-exclamation-triangle text-[var(--warning)]"></i> Alertas
                    </h3>
                    ${alertas.length === 0 && cancRecent.length === 0 ? `
                    <p class="text-[var(--text-muted)] text-sm">Nenhum alerta no momento.</p>
                    ` : `
                    <div class="space-y-2">
                        ${alertas.slice(0, 5).map(a => `
                        <div class="flex items-center justify-between p-2 rounded bg-[var(--bg-dark)]">
                            <div>
                                <p class="text-sm font-medium">${a.cliente.nome}</p>
                                <p class="text-xs text-[var(--text-muted)]">${a.dias} dias sem visita</p>
                            </div>
                            <span class="badge badge-warning">Ausente</span>
                        </div>
                        `).join('')}
                        ${cancRecent.map(x => {
                            const appt = DB.appointments.find(a => a.id === x.appointmentId);
                            const cl = appt ? getClient(appt.clienteId) : null;
                            return `
                            <div class="flex items-center justify-between p-2 rounded bg-[var(--bg-dark)]">
                                <div>
                                    <p class="text-sm font-medium">${cl ? cl.nome : 'Cliente'}</p>
                                    <p class="text-xs text-[var(--text-muted)]">${x.motivo}</p>
                                </div>
                                <span class="badge badge-danger">Cancelado</span>
                            </div>
                            `;
                        }).join('')}
                    </div>
                    `}
                </div>

                <div class="card">
                    <h3 class="font-semibold text-lg mb-3 flex items-center gap-2">
                        <i class="fas fa-star text-[var(--primary-light)]"></i> Próximos Agendamentos
                    </h3>
                    ${(() => {
                        const futuros = DB.appointments.filter(a => a.data > hoje && (a.status === 'agendado' || a.status === 'confirmado'))
                            .sort((a, b) => a.data.localeCompare(b.data) || a.hora.localeCompare(b.hora)).slice(0, 5);
                        if (futuros.length === 0) return '<p class="text-[var(--text-muted)] text-sm">Nenhum agendamento futuro.</p>';
                        return futuros.map(a => {
                            const cl = getClient(a.clienteId);
                            const sv = getService(a.servicoId);
                            return `
                            <div class="flex items-center justify-between p-2 rounded bg-[var(--bg-dark)]">
                                <div>
                                    <p class="text-sm font-medium">${cl ? cl.nome : 'Cliente'}</p>
                                    <p class="text-xs text-[var(--text-muted)]">${formatDate(a.data)} às ${a.hora} · ${sv ? sv.nome : ''}</p>
                                </div>
                                <span class="badge badge-info">${formatCurrency(a.valor)}</span>
                            </div>
                            `;
                        }).join('');
                    })()}
                </div>
            </div>
        </div>
    `;
}

function postRenderDashboard() {
    // Nenhuma ação extra necessária
}


/* --------------------------------------------------------------------------
   03.2 AGENDA
   Visão semanal (7 dias a partir de hoje) e tabela com todos os agendamentos.
   -------------------------------------------------------------------------- */

function renderAgenda() {
    const hoje = today();
    const diasSemana = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

    // Gera os 7 dias a partir de hoje
    const dias = [];
    for (let i = 0; i < 7; i++) {
        const d = new Date();
        d.setDate(d.getDate() + i);
        const ds = d.toISOString().split('T')[0];
        dias.push(ds);
    }
    const meses = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

    return `
        <div class="space-y-6">
            <!-- Cabeçalho com botões -->
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                    <h3 class="font-semibold text-lg">Agenda Semanal</h3>
                    <p class="text-sm text-[var(--text-muted)]">${formatDate(dias[0])} — ${formatDate(dias[6])}</p>
                </div>
                <div class="flex gap-2">
                    <button onclick="openModal('agendamento')" class="btn btn-primary btn-sm">
                        <i class="fas fa-plus"></i> Novo Agendamento
                    </button>
                    <button onclick="openModal('bloquear')" class="btn btn-secondary btn-sm">
                        <i class="fas fa-clock"></i> Bloquear
                    </button>
                </div>
            </div>

            <!-- Cards dos 7 dias -->
            <div class="overflow-x-auto">
                <div class="flex gap-3 min-w-[700px]" id="agendaCards">
                    ${dias.map(ds => {
                        const appts = getAppointmentsByDate(ds).filter(a => a.status !== 'cancelado').sort((a, b) => a.hora.localeCompare(b.hora));
                        const d = new Date(ds + 'T12:00:00');
                        const isToday = ds === hoje;
                        const working = isWorkingDay(ds);
                        return `
                        <div class="flex-1 min-w-[120px] card ${isToday ? 'ring-2 ring-[var(--primary)]' : ''}">
                            <div class="text-center mb-3">
                                <p class="text-xs text-[var(--text-muted)]">${diasSemana[d.getDay()]}</p>
                                <p class="text-2xl font-bold ${isToday ? 'text-[var(--primary-light)]' : ''}">${d.getDate()}</p>
                                <p class="text-xs text-[var(--text-muted)]">${meses[d.getMonth()]}</p>
                                ${!working ? '<span class="badge badge-danger text-xs mt-1">Fechado</span>' : ''}
                            </div>
                            ${!working ? '<p class="text-center text-xs text-[var(--text-muted)] py-4">Dia não útil</p>' :
                            appts.length === 0 ? '<p class="text-center text-xs text-[var(--text-muted)] py-4">Livre</p>' :
                            appts.map(a => {
                                const cl = getClient(a.clienteId);
                                const sv = getService(a.servicoId);
                                const br = getBarber(a.barbeiroId);
                                return `
                                <div class="text-xs p-2 mb-1 rounded bg-[var(--bg-dark)] border-l-2 ${a.status === 'confirmado' ? 'border-[var(--success)]' : 'border-[var(--primary)]'} cursor-pointer hover:bg-[var(--bg-elevated)]" onclick="openEditAppointment('${a.id}')">
                                    <p class="font-medium">${a.hora}</p>
                                    <p>${cl ? cl.nome.split(' ')[0] : '?'}</p>
                                    <p class="text-[var(--text-muted)]">${sv ? sv.nome.substring(0, 12) : '?'}</p>
                                </div>
                                `;
                            }).join('')}
                        </div>
                        `;
                    }).join('')}
                </div>
            </div>

            <!-- Tabela com os 30 agendamentos mais recentes -->
            <div class="card">
                <h3 class="font-semibold text-lg mb-3">Todos os Agendamentos</h3>
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Hora</th>
                                <th>Cliente</th>
                                <th>Serviço</th>
                                <th>Barbeiro</th>
                                <th>Valor</th>
                                <th>Status</th>
                                <th class="no-print">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${DB.appointments.sort((a, b) => b.data.localeCompare(a.data) || b.hora.localeCompare(a.hora)).slice(0, 30).map(a => {
                                const cl = getClient(a.clienteId);
                                const sv = getService(a.servicoId);
                                const br = getBarber(a.barbeiroId);
                                const statusClass = a.status === 'finalizado' ? 'badge-success' : a.status === 'cancelado' ? 'badge-danger' : a.status === 'confirmado' ? 'badge-info' : 'badge-warning';
                                return `
                                <tr>
                                    <td>${formatDate(a.data)}</td>
                                    <td>${a.hora}</td>
                                    <td>${cl ? cl.nome : '—'}</td>
                                    <td>${sv ? sv.nome : '—'}</td>
                                    <td>${br ? br.nome : '—'}</td>
                                    <td>${formatCurrency(a.valor)}</td>
                                    <td><span class="badge ${statusClass}">${a.status}</span></td>
                                    <td class="no-print">
                                        <button onclick="openEditAppointment('${a.id}')" class="btn btn-secondary btn-xs mr-1"><i class="fas fa-edit"></i></button>
                                        <button onclick="cancelAppointment('${a.id}')" class="btn btn-danger btn-xs"><i class="fas fa-times"></i></button>
                                    </td>
                                </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;
}

function postRenderAgenda() {}


/* --------------------------------------------------------------------------
   03.3 AGENDAMENTO
   Formulário completo para criar um novo agendamento.
   -------------------------------------------------------------------------- */

function renderAgendamento() {
    const barbeiros = DB.barbers.filter(b => b.ativo);
    const servicos = DB.services.filter(s => s.ativo);
    const clientes = DB.clients.filter(c => c.ativo);
    const hoje = today();

    return `
        <div class="max-w-2xl mx-auto">
            <div class="card">
                <h3 class="font-semibold text-xl mb-2">Novo Agendamento</h3>
                <p class="text-sm text-[var(--text-muted)] mb-6">Preencha os dados para agendar um horário.</p>
                <form id="agendamentoForm" onsubmit="submitAgendamento(event)" class="space-y-5">
                    <div>
                        <label class="form-label">Cliente *</label>
                        <select class="form-select" name="clienteId" required>
                            <option value="">Selecione um cliente</option>
                            ${clientes.map(c => `<option value="${c.id}">${c.nome}</option>`).join('')}
                        </select>
                        <p class="text-xs text-[var(--text-muted)] mt-1">
                            <a href="#" onclick="event.preventDefault(); navigate('clientes')" class="text-[var(--primary-light)]">+ Novo cliente</a>
                        </p>
                    </div>
                    <div>
                        <label class="form-label">Serviço *</label>
                        <select class="form-select" name="servicoId" required onchange="updatePrecoDados()">
                            <option value="">Selecione um serviço</option>
                            ${servicos.map(s => `<option value="${s.id}" data-preco="${s.preco}" data-duracao="${s.duracao}">${s.nome} — ${formatCurrency(s.preco)} (${s.duracao}min)</option>`).join('')}
                        </select>
                    </div>
                    <div>
                        <label class="form-label">Barbeiro *</label>
                        <select class="form-select" name="barbeiroId" required>
                            <option value="">Selecione um barbeiro</option>
                            ${barbeiros.map(b => `<option value="${b.id}">${b.nome}</option>`).join('')}
                        </select>
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">Data *</label>
                            <input type="date" class="form-input" name="data" value="${hoje}" min="${hoje}" required>
                        </div>
                        <div>
                            <label class="form-label">Horário *</label>
                            <select class="form-select" name="hora" required>
                                <option value="">Selecione</option>
                                ${gerarHorarios().map(h => `<option value="${h}">${h}</option>`).join('')}
                            </select>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">Valor (R$)</label>
                            <input type="number" class="form-input" name="valor" step="0.01" min="0" placeholder="Auto">
                        </div>
                        <div>
                            <label class="form-label">Forma de Pagamento</label>
                            <select class="form-select" name="formaPagamento">
                                <option value="">Selecione</option>
                                <option value="dinheiro">Dinheiro</option>
                                <option value="pix">PIX</option>
                                <option value="credito">Cartão de Crédito</option>
                                <option value="debito">Cartão de Débito</option>
                            </select>
                        </div>
                    </div>
                    <div>
                        <label class="form-label">Observações</label>
                        <textarea class="form-input" name="observacoes" rows="2" placeholder="Alguma observação especial?"></textarea>
                    </div>
                    <div class="flex items-center gap-3 pt-2">
                        <button type="submit" class="btn btn-primary"><i class="fas fa-check"></i> Confirmar Agendamento</button>
                        <button type="reset" class="btn btn-secondary">Limpar</button>
                    </div>
                </form>
            </div>
            <div class="mt-4 card">
                <p class="text-sm text-[var(--text-muted)]">
                    <i class="fas fa-info-circle mr-1"></i>
                    Após agendar, você pode enviar a confirmação por WhatsApp.
                </p>
            </div>
        </div>
    `;
}

/**
 * Gera a lista de horários disponíveis (ex.: 08:00, 08:30, ...)
 * com base nas configurações de horário de funcionamento.
 */
function gerarHorarios() {
    const { horarioInicio, horarioFim, intervaloDuracao } = DB.settings.workingHours;
    const [hI, mI] = horarioInicio.split(':').map(Number);
    const [hF, mF] = horarioFim.split(':').map(Number);
    const inicio = hI * 60 + mI;
    const fim = hF * 60 + mF;
    const horarios = [];
    for (let t = inicio; t + intervaloDuracao <= fim; t += intervaloDuracao) {
        const h = String(Math.floor(t / 60)).padStart(2, '0');
        const m = String(t % 60).padStart(2, '0');
        horarios.push(h + ':' + m);
    }
    return horarios;
}

/** Mostra o preço do serviço escolhido como sugestão no campo "Valor". */
function updatePrecoDados() {
    const sel = document.querySelector('select[name="servicoId"]');
    const opt = sel.options[sel.selectedIndex];
    if (opt && opt.dataset.preco) {
        const valorInput = document.querySelector('input[name="valor"]');
        if (valorInput && !valorInput.value) {
            valorInput.placeholder = opt.dataset.preco;
        }
    }
}

/** Valida e salva o agendamento feito na página "Agendamento". */
function submitAgendamento(e) {
    e.preventDefault();
    const form = e.target;
    const data = new FormData(form);
    const clienteId = data.get('clienteId');
    const servicoId = data.get('servicoId');
    const barbeiroId = data.get('barbeiroId');
    const dt = data.get('data');
    const hora = data.get('hora');
    const servico = getService(servicoId);
    const valor = parseFloat(data.get('valor')) || (servico ? servico.preco : 0);
    const formaPagamento = data.get('formaPagamento') || '';
    const observacoes = data.get('observacoes') || '';

    if (!clienteId || !servicoId || !barbeiroId || !dt || !hora) {
        showToast('Preencha todos os campos obrigatórios.', 'error');
        return;
    }

    // Verifica se o horário já está ocupado para este barbeiro
    const conflito = DB.appointments.some(a => a.data === dt && a.hora === hora && a.barbeiroId === barbeiroId && a.status !== 'cancelado');
    if (conflito) {
        showToast('Este horário já está agendado para este barbeiro.', 'error');
        return;
    }

    const novo = {
        id: generateId(),
        clienteId,
        servicoId,
        barbeiroId,
        data: dt,
        hora,
        status: 'agendado',
        valor,
        formaPagamento,
        observacoes
    };
    DB.appointments.push(novo);
    saveData();
    showToast('Agendamento criado com sucesso!', 'success');
    form.reset();

    // Atualiza a última visita do cliente
    const cl = getClient(clienteId);
    if (cl) {
        cl.ultimaVisita = dt;
        saveData();
    }
    navigate('agenda');
}

function postRenderAgendamento() {}


/* --------------------------------------------------------------------------
   03.4 CLIENTES
   Lista de clientes com busca, edição, ativar/inativar e histórico.
   -------------------------------------------------------------------------- */

function renderClientes() {
    return `
        <div class="space-y-6">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <h3 class="font-semibold text-lg">Clientes</h3>
                <button onclick="openModal('cliente')" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Novo Cliente</button>
            </div>
            <div class="card">
                <!-- Campo de busca -->
                <div class="mb-4">
                    <input type="text" class="form-input max-w-md" id="clienteSearch" placeholder="Buscar cliente..." oninput="filterClientes()">
                </div>
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Telefone</th>
                                <th>Última Visita</th>
                                <th>Status</th>
                                <th>Preferências</th>
                                <th class="no-print">Ações</th>
                            </tr>
                        </thead>
                        <tbody id="clientesTableBody">
                            ${DB.clients.map(c => {
                                const diasUltima = c.ultimaVisita ? Math.floor((new Date() - new Date(c.ultimaVisita + 'T12:00:00')) / (1000 * 60 * 60 * 24)) : '—';
                                return `
                                <tr class="${!c.ativo ? 'opacity-50' : ''}">
                                    <td class="font-medium">${c.nome}</td>
                                    <td>${c.telefone}</td>
                                    <td>${c.ultimaVisita ? formatDate(c.ultimaVisita) + ' (' + diasUltima + 'd)' : 'Nunca'}</td>
                                    <td><span class="badge ${c.ativo ? 'badge-success' : 'badge-danger'}">${c.ativo ? 'Ativo' : 'Inativo'}</span></td>
                                    <td class="text-sm text-[var(--text-secondary)] max-w-[200px] truncate">${c.preferencias || '—'}</td>
                                    <td class="no-print">
                                        <button onclick="openEditCliente('${c.id}')" class="btn btn-secondary btn-xs mr-1"><i class="fas fa-edit"></i></button>
                                        <button onclick="toggleClienteStatus('${c.id}')" class="btn btn-secondary btn-xs mr-1"><i class="fas ${c.ativo ? 'fa-user-slash' : 'fa-user-check'}"></i></button>
                                        <button onclick="viewClienteHistory('${c.id}')" class="btn btn-secondary btn-xs"><i class="fas fa-history"></i></button>
                                    </td>
                                </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;
}

/** Filtra as linhas da tabela de clientes pelo nome digitado. */
function filterClientes() {
    const q = document.getElementById('clienteSearch').value.toLowerCase();
    const rows = document.querySelectorAll('#clientesTableBody tr');
    rows.forEach(row => {
        const nome = row.cells[0]?.textContent.toLowerCase() || '';
        row.style.display = nome.includes(q) ? '' : 'none';
    });
}

/** Ativa ou inativa um cliente. */
function toggleClienteStatus(id) {
    const c = DB.clients.find(cl => cl.id === id);
    if (c) {
        c.ativo = !c.ativo;
        saveData();
        showToast(`Cliente ${c.ativo ? 'ativado' : 'inativado'} com sucesso.`, 'success');
        renderCurrentPage();
    }
}

/** Abre um modal com o histórico de atendimentos do cliente. */
function viewClienteHistory(id) {
    const c = getClient(id);
    if (!c) return;
    const appts = DB.appointments.filter(a => a.clienteId === id).sort((a, b) => b.data.localeCompare(a.data));
    const totalGasto = appts.reduce((s, a) => s + a.valor, 0);
    const servicos = appts.map(a => getService(a.servicoId)).filter(Boolean);
    const servicosNomes = [...new Set(servicos.map(s => s.nome))];

    let html = `
        <div class="space-y-4">
            <div class="flex items-center gap-3">
                <div class="w-14 h-14 rounded-full bg-[var(--primary)] flex items-center justify-center text-white font-bold text-xl">${c.nome.charAt(0)}</div>
                <div>
                    <h3 class="font-bold text-lg">${c.nome}</h3>
                    <p class="text-sm text-[var(--text-muted)]">${c.telefone} · ${c.email}</p>
                </div>
            </div>
            <div class="grid grid-cols-2 gap-3">
                <div class="p-3 rounded bg-[var(--bg-dark)]">
                    <p class="text-xs text-[var(--text-muted)]">Total Gasto</p>
                    <p class="font-bold text-lg text-[var(--primary-light)]">${formatCurrency(totalGasto)}</p>
                </div>
                <div class="p-3 rounded bg-[var(--bg-dark)]">
                    <p class="text-xs text-[var(--text-muted)]">Atendimentos</p>
                    <p class="font-bold text-lg">${appts.length}</p>
                </div>
            </div>
            ${c.preferencias ? `<p class="text-sm"><span class="text-[var(--text-muted)]">Preferências:</span> ${c.preferencias}</p>` : ''}
            ${c.observacoes ? `<p class="text-sm"><span class="text-[var(--text-muted)]">Obs:</span> ${c.observacoes}</p>` : ''}
            <div>
                <h4 class="font-semibold mb-2">Histórico de Atendimentos</h4>
                ${appts.length === 0 ? '<p class="text-sm text-[var(--text-muted)]">Nenhum atendimento registrado.</p>' :
                appts.slice(0, 10).map(a => {
                    const sv = getService(a.servicoId);
                    const br = getBarber(a.barbeiroId);
                    const statusClass = a.status === 'finalizado' ? 'badge-success' : a.status === 'cancelado' ? 'badge-danger' : 'badge-info';
                    return `
                    <div class="flex items-center justify-between p-2 border-b border-[var(--border-color)] text-sm">
                        <span>${formatDate(a.data)} às ${a.hora}</span>
                        <span>${sv ? sv.nome : '—'}</span>
                        <span>${br ? br.nome : '—'}</span>
                        <span>${formatCurrency(a.valor)}</span>
                        <span class="badge ${statusClass}">${a.status}</span>
                    </div>
                    `;
                }).join('')}
            </div>
        </div>
    `;
    openModalWithContent(html);
}


/* --------------------------------------------------------------------------
   03.5 SERVIÇOS
   Cards dos serviços com editar e ativar/desativar.
   -------------------------------------------------------------------------- */

function renderServicos() {
    return `
        <div class="space-y-6">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <h3 class="font-semibold text-lg">Serviços</h3>
                <button onclick="openModal('servico')" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Novo Serviço</button>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                ${DB.services.map(s => `
                <div class="card flex flex-col justify-between ${!s.ativo ? 'opacity-50' : ''}">
                    <div>
                        <div class="flex items-center justify-between mb-2">
                            <h4 class="font-semibold text-lg">${s.nome}</h4>
                            <span class="text-lg font-bold text-[var(--primary-light)]">${formatCurrency(s.preco)}</span>
                        </div>
                        <p class="text-sm text-[var(--text-secondary)] mb-3">${s.descricao}</p>
                        <p class="text-xs text-[var(--text-muted)]"><i class="far fa-clock mr-1"></i>${s.duracao} minutos</p>
                    </div>
                    <div class="flex gap-2 mt-4 pt-3 border-t border-[var(--border-color)]">
                        <button onclick="openEditServico('${s.id}')" class="btn btn-secondary btn-xs"><i class="fas fa-edit"></i> Editar</button>
                        <button onclick="toggleServicoStatus('${s.id}')" class="btn btn-secondary btn-xs"><i class="fas ${s.ativo ? 'fa-eye-slash' : 'fa-eye'}"></i></button>
                    </div>
                </div>
                `).join('')}
            </div>
        </div>
    `;
}

/** Ativa ou desativa um serviço. */
function toggleServicoStatus(id) {
    const s = DB.services.find(se => se.id === id);
    if (s) {
        s.ativo = !s.ativo;
        saveData();
        showToast(`Serviço ${s.ativo ? 'ativado' : 'desativado'}.`, 'success');
        renderCurrentPage();
    }
}


/* --------------------------------------------------------------------------
   03.6 RETENÇÃO
   Clientes ausentes (> 45 dias), lista de espera e cancelamentos.
   -------------------------------------------------------------------------- */

function renderRetencao() {
    const hoje = new Date();
    const inativos = DB.clients.filter(c => {
        if (!c.ultimaVisita || !c.ativo) return false;
        const dias = Math.floor((hoje - new Date(c.ultimaVisita + 'T12:00:00')) / (1000 * 60 * 60 * 24));
        return dias > 45;
    });
    const waitlist = DB.waitlist;

    return `
        <div class="space-y-6">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Clientes ausentes -->
                <div class="card">
                    <h3 class="font-semibold text-lg mb-3 flex items-center gap-2">
                        <i class="fas fa-user-clock text-[var(--warning)]"></i> Clientes Ausentes (>45 dias)
                    </h3>
                    ${inativos.length === 0 ? `
                    <p class="text-[var(--text-muted)] text-sm py-4">Nenhum cliente ausente no momento. 🎉</p>
                    ` : `
                    <div class="space-y-2">
                        ${inativos.map(c => {
                            const dias = Math.floor((hoje - new Date(c.ultimaVisita + 'T12:00:00')) / (1000 * 60 * 60 * 24));
                            return `
                            <div class="flex items-center justify-between p-3 rounded bg-[var(--bg-dark)]">
                                <div>
                                    <p class="font-medium">${c.nome}</p>
                                    <p class="text-xs text-[var(--text-muted)]">Última visita: ${formatDate(c.ultimaVisita)} (${dias} dias)</p>
                                </div>
                                <div class="flex gap-2">
                                    <button onclick="sendReminder('${c.id}')" class="btn btn-primary btn-xs"><i class="fab fa-whatsapp"></i> Lembrete</button>
                                    <button onclick="addToWaitlist('${c.id}')" class="btn btn-secondary btn-xs"><i class="fas fa-list"></i> Lista</button>
                                </div>
                            </div>
                            `;
                        }).join('')}
                    </div>
                    `}
                </div>

                <!-- Lista de espera -->
                <div class="card">
                    <h3 class="font-semibold text-lg mb-3 flex items-center gap-2">
                        <i class="fas fa-list-ol text-[var(--primary-light)]"></i> Lista de Espera
                    </h3>
                    ${waitlist.length === 0 ? `
                    <p class="text-[var(--text-muted)] text-sm py-4">Lista de espera vazia.</p>
                    ` : `
                    <div class="space-y-2">
                        ${waitlist.map(w => {
                            const cl = getClient(w.clienteId);
                            const sv = getService(w.servicoId);
                            return `
                            <div class="flex items-center justify-between p-3 rounded bg-[var(--bg-dark)]">
                                <div>
                                    <p class="font-medium">${cl ? cl.nome : 'Cliente'}</p>
                                    <p class="text-xs text-[var(--text-muted)]">${sv ? sv.nome : 'Serviço'} · ${formatDate(w.dataSolicitacao)}</p>
                                </div>
                                <button onclick="removeFromWaitlist('${w.id}')" class="btn btn-danger btn-xs"><i class="fas fa-times"></i></button>
                            </div>
                            `;
                        }).join('')}
                    </div>
                    `}
                </div>
            </div>

            <!-- Cancelamentos e faltas -->
            <div class="card">
                <h3 class="font-semibold text-lg mb-3">Cancelamentos e Faltas</h3>
                <div class="table-wrap">
                    <table>
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Cliente</th>
                                <th>Motivo</th>
                                <th>Responsável</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${DB.cancellations.length === 0 ? '<tr><td colspan="4" class="text-center text-[var(--text-muted)]">Nenhum cancelamento registrado.</td></tr>' :
                            DB.cancellations.sort((a, b) => b.data.localeCompare(a.data)).map(x => {
                                const appt = DB.appointments.find(ap => ap.id === x.appointmentId);
                                const cl = appt ? getClient(appt.clienteId) : null;
                                return `
                                <tr>
                                    <td>${formatDate(x.data)}</td>
                                    <td>${cl ? cl.nome : '—'}</td>
                                    <td>${x.motivo}</td>
                                    <td>${x.por === 'cliente' ? 'Cliente' : 'Barbearia'}</td>
                                </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    `;
}

/** Abre o WhatsApp com uma mensagem de lembrete para o cliente ausente. */
function sendReminder(clienteId) {
    const c = getClient(clienteId);
    if (!c) return;
    const msg = encodeURIComponent(`Olá ${c.nome}! Tudo bem? Passando para lembrar que já faz um tempinho que você não visita a barbearia. Que tal agendar um horário? Estamos esperando por você! 😃✂️`);
    const whats = DB.settings.barberShop.whatsapp || '5511999999999';
    window.open(`https://wa.me/${whats}?text=${msg}`, '_blank');
    showToast('Lembrete enviado com sucesso!', 'success');
}

/** Adiciona um cliente à lista de espera (sem duplicar). */
function addToWaitlist(clienteId) {
    if (DB.waitlist.some(w => w.clienteId === clienteId)) {
        showToast('Cliente já está na lista de espera.', 'warning');
        return;
    }
    DB.waitlist.push({
        id: generateId(),
        clienteId,
        servicoId: DB.services[0]?.id || '',
        dataSolicitacao: today(),
        observacoes: ''
    });
    saveData();
    showToast('Adicionado à lista de espera.', 'success');
    renderCurrentPage();
}

/** Remove um item da lista de espera. */
function removeFromWaitlist(id) {
    DB.waitlist = DB.waitlist.filter(w => w.id !== id);
    saveData();
    showToast('Removido da lista de espera.', 'info');
    renderCurrentPage();
}


/* --------------------------------------------------------------------------
   03.7 FINANCEIRO
   Faturamento do mês, ticket médio, últimos 6 meses e formas de pagamento.
   -------------------------------------------------------------------------- */

function renderFinanceiro() {
    const hoje = today();
    const mesAtual = hoje.substring(0, 7);
    const apptsMes = DB.appointments.filter(a => a.data.startsWith(mesAtual) && a.status !== 'cancelado');
    const finalizadosMes = apptsMes.filter(a => a.status === 'finalizado');
    const faturamentoMes = finalizadosMes.reduce((s, a) => s + a.valor, 0);
    const totalApptsMes = apptsMes.length;
    const ticketMedio = finalizadosMes.length > 0 ? faturamentoMes / finalizadosMes.length : 0;

    // Total por forma de pagamento (somente atendimentos finalizados no mês)
    const formas = {};
    finalizadosMes.forEach(a => {
        const f = a.formaPagamento || 'outro';
        formas[f] = (formas[f] || 0) + a.valor;
    });

    // Faturamento dos últimos 6 meses
    const meses = [];
    for (let i = 5; i >= 0; i--) {
        const d = new Date();
        d.setMonth(d.getMonth() - i);
        const key = d.toISOString().substring(0, 7);
        const nome = d.toLocaleDateString('pt-BR', { month: 'short', timeZone: 'UTC' });
        const appts = DB.appointments.filter(a => a.data.startsWith(key) && a.status === 'finalizado');
        const fat = appts.reduce((s, a) => s + a.valor, 0);
        meses.push({ key, nome, fat, qtd: appts.length });
    }

    return `
        <div class="space-y-6">
            <!-- Indicadores -->
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="card">
                    <p class="text-[var(--text-muted)] text-sm">Faturamento do Mês</p>
                    <p class="text-3xl font-bold mt-1 text-[var(--primary-light)]">${formatCurrency(faturamentoMes)}</p>
                </div>
                <div class="card">
                    <p class="text-[var(--text-muted)] text-sm">Atendimentos no Mês</p>
                    <p class="text-3xl font-bold mt-1">${totalApptsMes}</p>
                    <p class="text-xs text-[var(--text-muted)]">${finalizadosMes.length} finalizados</p>
                </div>
                <div class="card">
                    <p class="text-[var(--text-muted)] text-sm">Ticket Médio</p>
                    <p class="text-3xl font-bold mt-1">${formatCurrency(ticketMedio)}</p>
                </div>
                <div class="card">
                    <p class="text-[var(--text-muted)] text-sm">Agendamentos Pendentes</p>
                    <p class="text-3xl font-bold mt-1">${apptsMes.filter(a => a.status === 'agendado' || a.status === 'confirmado').length}</p>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Gráfico de barras: faturamento mensal -->
                <div class="card">
                    <h3 class="font-semibold text-lg mb-3">Faturamento Mensal</h3>
                    <div class="space-y-3">
                        ${meses.map(m => {
                            const max = Math.max(...meses.map(x => x.fat), 1);
                            const pct = (m.fat / max) * 100;
                            return `
                            <div>
                                <div class="flex justify-between text-sm mb-1">
                                    <span>${m.nome}</span>
                                    <span class="font-medium">${formatCurrency(m.fat)} (${m.qtd} atd.)</span>
                                </div>
                                <div class="w-full bg-[var(--bg-dark)] rounded-full h-2">
                                    <div class="bg-[var(--primary)] h-2 rounded-full" style="width:${pct}%"></div>
                                </div>
                            </div>
                            `;
                        }).join('')}
                    </div>
                </div>

                <!-- Gráfico de barras: formas de pagamento -->
                <div class="card">
                    <h3 class="font-semibold text-lg mb-3">Formas de Pagamento (Mês)</h3>
                    ${Object.keys(formas).length === 0 ? '<p class="text-[var(--text-muted)] text-sm">Nenhum pagamento registrado no mês.</p>' :
                    `
                    <div class="space-y-3">
                        ${Object.entries(formas).map(([forma, valor]) => {
                            const total = Object.values(formas).reduce((s, v) => s + v, 0);
                            const pct = total > 0 ? (valor / total) * 100 : 0;
                            const nomes = { pix: 'PIX', dinheiro: 'Dinheiro', credito: 'Cartão Crédito', debito: 'Cartão Débito', outro: 'Outro' };
                            return `
                            <div>
                                <div class="flex justify-between text-sm mb-1">
                                    <span>${nomes[forma] || forma}</span>
                                    <span class="font-medium">${formatCurrency(valor)} (${pct.toFixed(0)}%)</span>
                                </div>
                                <div class="w-full bg-[var(--bg-dark)] rounded-full h-2">
                                    <div class="bg-[var(--primary-light)] h-2 rounded-full" style="width:${pct}%"></div>
                                </div>
                            </div>
                            `;
                        }).join('')}
                    </div>
                    `}
                </div>
            </div>
        </div>
    `;
}

function postRenderFinanceiro() {}


/* --------------------------------------------------------------------------
   03.8 SITE DA BARBEARIA
   Pré-visualização do site público: hero, sobre, serviços, equipe,
   galeria, endereço e horários.
   -------------------------------------------------------------------------- */

function renderSite() {
    const shop = DB.settings.barberShop;
    const ativos = DB.barbers.filter(b => b.ativo);

    return `
        <div class="space-y-8">
            <!-- Hero -->
            <div class="hero-gradient rounded-2xl p-8 lg:p-16 text-center relative overflow-hidden">
                <div class="relative z-10">
                    <div class="inline-block">
                        <div class="w-20 h-20 mx-auto mb-4 rounded-2xl bg-[var(--primary)] flex items-center justify-center text-white font-bold text-3xl">BF</div>
                    </div>
                    <h1 class="text-4xl lg:text-5xl font-extrabold mb-3">${shop.nome}</h1>
                    <p class="text-xl text-[var(--text-secondary)] max-w-lg mx-auto">${shop.descricao}</p>
                    <div class="flex flex-wrap justify-center gap-3 mt-6">
                        <a href="https://wa.me/${shop.whatsapp}" target="_blank" class="btn btn-primary"><i class="fab fa-whatsapp"></i> Agende seu Horário</a>
                        <a href="https://instagram.com/${shop.instagram.replace('@', '')}" target="_blank" class="btn btn-secondary"><i class="fab fa-instagram"></i> Instagram</a>
                    </div>
                </div>
                <div class="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
            </div>

            <!-- Sobre -->
            <div class="card">
                <h2 class="text-2xl font-bold mb-3">Sobre Nós</h2>
                <p class="text-[var(--text-secondary)]">${shop.sobre}</p>
            </div>

            <!-- Serviços -->
            <div>
                <h2 class="text-2xl font-bold mb-4">Nossos Serviços</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    ${DB.services.filter(s => s.ativo).map(s => `
                    <div class="card text-center hover:border-[var(--primary)] transition-colors">
                        <div class="w-12 h-12 mx-auto mb-3 rounded-full bg-[var(--primary)]/20 flex items-center justify-center text-[var(--primary-light)]">
                            <i class="fas fa-cut"></i>
                        </div>
                        <h3 class="font-semibold text-lg">${s.nome}</h3>
                        <p class="text-sm text-[var(--text-secondary)] mb-2">${s.descricao}</p>
                        <p class="font-bold text-xl text-[var(--primary-light)]">${formatCurrency(s.preco)}</p>
                        <p class="text-xs text-[var(--text-muted)]">${s.duracao} min</p>
                    </div>
                    `).join('')}
                </div>
            </div>

            <!-- Equipe -->
            <div>
                <h2 class="text-2xl font-bold mb-4">Nossa Equipe</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    ${ativos.map(b => `
                    <div class="card text-center">
                        <img src="${b.foto}" alt="${b.nome}" class="w-24 h-24 mx-auto rounded-full object-cover mb-3" loading="lazy">
                        <h3 class="font-semibold text-lg">${b.nome}</h3>
                        <p class="text-sm text-[var(--text-muted)]">Barbeiro</p>
                    </div>
                    `).join('')}
                </div>
            </div>

            <!-- Galeria -->
            <div>
                <h2 class="text-2xl font-bold mb-4">Galeria</h2>
                <div class="gallery-grid">
                    ${[1, 2, 3, 4, 5, 6].map(n => `
                    <img src="https://picsum.photos/300/300?random=${200 + n}" alt="Corte ${n}" class="rounded-lg" loading="lazy">
                    `).join('')}
                </div>
            </div>

            <!-- Endereço e horários -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="card">
                    <h3 class="font-semibold text-lg mb-3"><i class="fas fa-map-marker-alt text-[var(--danger)] mr-2"></i> Endereço</h3>
                    <p>${shop.endereco}</p>
                    <div class="mt-3 rounded-lg overflow-hidden h-48 bg-[var(--bg-dark)] flex items-center justify-center text-[var(--text-muted)]">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.0!2d-46.6!3d-23.5!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjPCsDMwJzAwLjAiUyA0NsKwMzYnMDAuMCJX!5e0!3m2!1spt-BR!2sbr!4v1" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div>
                </div>
                <div class="card">
                    <h3 class="font-semibold text-lg mb-3"><i class="far fa-clock text-[var(--primary-light)] mr-2"></i> Horários</h3>
                    <div class="space-y-2">
                        ${['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map((dia, idx) => {
                            const pt = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sab'][idx];
                            const aberto = DB.settings.workingHours.dias.includes(pt);
                            return `
                            <div class="flex justify-between text-sm py-1 border-b border-[var(--border-color)] last:border-0">
                                <span>${dia}</span>
                                <span class="${aberto ? 'text-[var(--success)]' : 'text-[var(--danger)]'}">${aberto ? DB.settings.workingHours.horarioInicio + ' — ' + DB.settings.workingHours.horarioFim : 'Fechado'}</span>
                            </div>
                            `;
                        }).join('')}
                    </div>
                    <div class="mt-4 space-y-2">
                        <a href="https://wa.me/${shop.whatsapp}" target="_blank" class="flex items-center gap-2 text-sm text-[var(--primary-light)]">
                            <i class="fab fa-whatsapp"></i> ${shop.telefone}
                        </a>
                        <a href="https://instagram.com/${shop.instagram.replace('@', '')}" target="_blank" class="flex items-center gap-2 text-sm text-[var(--primary-light)]">
                            <i class="fab fa-instagram"></i> ${shop.instagram}
                        </a>
                    </div>
                </div>
            </div>
        </div>
    `;
}


/* --------------------------------------------------------------------------
   03.9 RELATÓRIOS
   Indicadores gerais, serviços mais realizados e cancelamentos por mês.
   -------------------------------------------------------------------------- */

function renderRelatorios() {
    const totalAppts = DB.appointments.length;
    const finalizados = DB.appointments.filter(a => a.status === 'finalizado');
    const cancelados = DB.appointments.filter(a => a.status === 'cancelado');
    const totalFaturamento = finalizados.reduce((s, a) => s + a.valor, 0);

    // Conta quantas vezes cada serviço foi realizado
    const servicosCount = {};
    DB.appointments.filter(a => a.status === 'finalizado').forEach(a => {
        const sv = getService(a.servicoId);
        const nome = sv ? sv.nome : 'Desconhecido';
        servicosCount[nome] = (servicosCount[nome] || 0) + 1;
    });
    const servicosRank = Object.entries(servicosCount).sort((a, b) => b[1] - a[1]);

    // Ocupação aproximada (estimativa simples)
    const ocupacao = DB.appointments.filter(a => a.status !== 'cancelado').length;
    const totalHorarios = DB.settings.workingHours.dias.length * 12; // aproximado

    return `
        <div class="space-y-6">
            <!-- Indicadores -->
            <div class="grid grid-cols-2 lg:grid-cols-5 gap-4">
                <div class="card">
                    <p class="text-[var(--text-muted)] text-xs">Faturamento Total</p>
                    <p class="text-2xl font-bold text-[var(--primary-light)]">${formatCurrency(totalFaturamento)}</p>
                </div>
                <div class="card">
                    <p class="text-[var(--text-muted)] text-xs">Atendimentos</p>
                    <p class="text-2xl font-bold">${finalizados.length}</p>
                </div>
                <div class="card">
                    <p class="text-[var(--text-muted)] text-xs">Cancelamentos</p>
                    <p class="text-2xl font-bold text-[var(--danger)]">${cancelados.length}</p>
                </div>
                <div class="card">
                    <p class="text-[var(--text-muted)] text-xs">Total Agendamentos</p>
                    <p class="text-2xl font-bold">${totalAppts}</p>
                </div>
                <div class="card">
                    <p class="text-[var(--text-muted)] text-xs">Ocupação Aprox.</p>
                    <p class="text-2xl font-bold">${totalHorarios > 0 ? Math.round((ocupacao / totalHorarios) * 100) : 0}%</p>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Ranking de serviços -->
                <div class="card">
                    <h3 class="font-semibold text-lg mb-3">Serviços Mais Realizados</h3>
                    ${servicosRank.length === 0 ? '<p class="text-[var(--text-muted)] text-sm">Nenhum serviço finalizado.</p>' :
                    `
                    <div class="space-y-3">
                        ${servicosRank.map(([nome, qtd], idx) => {
                            const max = servicosRank[0]?.[1] || 1;
                            const pct = (qtd / max) * 100;
                            return `
                            <div>
                                <div class="flex justify-between text-sm mb-1">
                                    <span>${idx + 1}. ${nome}</span>
                                    <span class="font-medium">${qtd}x</span>
                                </div>
                                <div class="w-full bg-[var(--bg-dark)] rounded-full h-2">
                                    <div class="bg-[var(--primary)] h-2 rounded-full" style="width:${pct}%"></div>
                                </div>
                            </div>
                            `;
                        }).join('')}
                    </div>
                    `}
                </div>

                <!-- Cancelamentos por mês -->
                <div class="card">
                    <h3 class="font-semibold text-lg mb-3">Cancelamentos por Período</h3>
                    ${cancelados.length === 0 ? '<p class="text-[var(--text-muted)] text-sm">Nenhum cancelamento registrado.</p>' :
                    (() => {
                        const porMes = {};
                        cancelados.forEach(a => {
                            const mes = a.data.substring(0, 7);
                            porMes[mes] = (porMes[mes] || 0) + 1;
                        });
                        const entries = Object.entries(porMes).sort((a, b) => a[0].localeCompare(b[0]));
                        const max = Math.max(...entries.map(e => e[1]), 1);
                        return entries.map(([mes, qtd]) => {
                            const pct = (qtd / max) * 100;
                            const nome = new Date(mes + '-01T12:00:00').toLocaleDateString('pt-BR', { month: 'short', year: '2-digit', timeZone: 'UTC' });
                            return `
                            <div>
                                <div class="flex justify-between text-sm mb-1">
                                    <span>${nome}</span>
                                    <span class="font-medium">${qtd} cancel.</span>
                                </div>
                                <div class="w-full bg-[var(--bg-dark)] rounded-full h-2">
                                    <div class="bg-[var(--danger)] h-2 rounded-full" style="width:${pct}%"></div>
                                </div>
                            </div>
                            `;
                        }).join('');
                    })()}
                </div>
            </div>
        </div>
    `;
}

function postRenderRelatorios() {}


/* --------------------------------------------------------------------------
   03.10 CONFIGURAÇÕES
   Dados da barbearia, horários, barbeiros e gerenciamento de dados.
   -------------------------------------------------------------------------- */

function renderConfiguracoes() {
    const shop = DB.settings.barberShop;
    const wh = DB.settings.workingHours;
    const diasSemana = [
        { key: 'dom', label: 'Domingo' },
        { key: 'seg', label: 'Segunda' },
        { key: 'ter', label: 'Terça' },
        { key: 'qua', label: 'Quarta' },
        { key: 'qui', label: 'Quinta' },
        { key: 'sex', label: 'Sexta' },
        { key: 'sab', label: 'Sábado' }
    ];

    return `
        <div class="max-w-3xl mx-auto space-y-6">
            <!-- Dados da barbearia -->
            <div class="card">
                <h3 class="font-semibold text-lg mb-4">Dados da Barbearia</h3>
                <form id="configForm" onsubmit="saveConfig(event)" class="space-y-4">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">Nome da Barbearia</label>
                            <input type="text" class="form-input" name="nome" value="${shop.nome}" required>
                        </div>
                        <div>
                            <label class="form-label">Telefone</label>
                            <input type="text" class="form-input" name="telefone" value="${shop.telefone}">
                        </div>
                        <div>
                            <label class="form-label">WhatsApp (número)</label>
                            <input type="text" class="form-input" name="whatsapp" value="${shop.whatsapp}">
                        </div>
                        <div>
                            <label class="form-label">Instagram</label>
                            <input type="text" class="form-input" name="instagram" value="${shop.instagram}">
                        </div>
                    </div>
                    <div>
                        <label class="form-label">Endereço</label>
                        <input type="text" class="form-input" name="endereco" value="${shop.endereco}">
                    </div>
                    <div>
                        <label class="form-label">Descrição (curta)</label>
                        <input type="text" class="form-input" name="descricao" value="${shop.descricao}">
                    </div>
                    <div>
                        <label class="form-label">Sobre</label>
                        <textarea class="form-input" name="sobre" rows="3">${shop.sobre}</textarea>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Salvar Configurações</button>
                </form>
            </div>

            <!-- Horários de funcionamento -->
            <div class="card">
                <h3 class="font-semibold text-lg mb-4">Horários de Funcionamento</h3>
                <form id="hoursForm" onsubmit="saveHours(event)" class="space-y-4">
                    <div>
                        <label class="form-label mb-2">Dias de Funcionamento</label>
                        <div class="flex flex-wrap gap-3">
                            ${diasSemana.map(d => `
                            <label class="flex items-center gap-2 text-sm cursor-pointer">
                                <input type="checkbox" name="dias" value="${d.key}" ${wh.dias.includes(d.key) ? 'checked' : ''} class="accent-[var(--primary)]">
                                ${d.label}
                            </label>
                            `).join('')}
                        </div>
                    </div>
                    <div class="grid grid-cols-2 sm:grid-cols-3 gap-4">
                        <div>
                            <label class="form-label">Horário Início</label>
                            <input type="time" class="form-input" name="horarioInicio" value="${wh.horarioInicio}" required>
                        </div>
                        <div>
                            <label class="form-label">Horário Fim</label>
                            <input type="time" class="form-input" name="horarioFim" value="${wh.horarioFim}" required>
                        </div>
                        <div>
                            <label class="form-label">Intervalo (min)</label>
                            <input type="number" class="form-input" name="intervaloDuracao" value="${wh.intervaloDuracao}" min="15" max="120" step="5" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Salvar Horários</button>
                </form>
            </div>

            <!-- Barbeiros -->
            <div class="card">
                <h3 class="font-semibold text-lg mb-4">Gerenciar Barbeiros</h3>
                <div class="space-y-3 mb-4">
                    ${DB.barbers.map(b => `
                    <div class="flex items-center justify-between p-3 rounded bg-[var(--bg-dark)]">
                        <div class="flex items-center gap-3">
                            <img src="${b.foto}" alt="${b.nome}" class="w-10 h-10 rounded-full object-cover" loading="lazy">
                            <div>
                                <p class="font-medium">${b.nome}</p>
                                <span class="badge ${b.ativo ? 'badge-success' : 'badge-danger'}">${b.ativo ? 'Ativo' : 'Inativo'}</span>
                            </div>
                        </div>
                        <div class="flex gap-2">
                            <button onclick="openEditBarber('${b.id}')" class="btn btn-secondary btn-xs"><i class="fas fa-edit"></i></button>
                            <button onclick="toggleBarberStatus('${b.id}')" class="btn btn-secondary btn-xs"><i class="fas ${b.ativo ? 'fa-eye-slash' : 'fa-eye'}"></i></button>
                        </div>
                    </div>
                    `).join('')}
                </div>
                <button onclick="openModal('barbeiro')" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Novo Barbeiro</button>
            </div>

            <!-- Gerenciar dados -->
            <div class="card">
                <h3 class="font-semibold text-lg mb-4">Gerenciar Dados</h3>
                <div class="flex flex-wrap gap-3">
                    <button onclick="exportData()" class="btn btn-secondary"><i class="fas fa-download"></i> Exportar Dados (JSON)</button>
                    <button onclick="importData()" class="btn btn-secondary"><i class="fas fa-upload"></i> Importar Dados</button>
                    <button onclick="resetData()" class="btn btn-danger"><i class="fas fa-trash-alt"></i> Resetar Dados</button>
                </div>
                <p class="text-xs text-[var(--text-muted)] mt-3">Os dados são armazenados no navegador (LocalStorage).</p>
            </div>
        </div>
    `;
}

/** Salva os dados da barbearia (formulário de configurações). */
function saveConfig(e) {
    e.preventDefault();
    const data = new FormData(e.target);
    const shop = DB.settings.barberShop;
    shop.nome = data.get('nome');
    shop.telefone = data.get('telefone');
    shop.whatsapp = data.get('whatsapp');
    shop.instagram = data.get('instagram');
    shop.endereco = data.get('endereco');
    shop.descricao = data.get('descricao');
    shop.sobre = data.get('sobre');
    saveData();
    showToast('Configurações salvas com sucesso!', 'success');
    renderCurrentPage();
}

/** Salva os horários de funcionamento. */
function saveHours(e) {
    e.preventDefault();
    const data = new FormData(e.target);
    const dias = data.getAll('dias');
    const wh = DB.settings.workingHours;
    wh.dias = dias;
    wh.horarioInicio = data.get('horarioInicio');
    wh.horarioFim = data.get('horarioFim');
    wh.intervaloDuracao = parseInt(data.get('intervaloDuracao')) || 30;
    saveData();
    showToast('Horários salvos com sucesso!', 'success');
    renderCurrentPage();
}

/** Ativa ou desativa um barbeiro. */
function toggleBarberStatus(id) {
    const b = DB.barbers.find(bar => bar.id === id);
    if (b) {
        b.ativo = !b.ativo;
        saveData();
        showToast(`Barbeiro ${b.ativo ? 'ativado' : 'desativado'}.`, 'success');
        renderCurrentPage();
    }
}


/* ==========================================================================
   04. SISTEMA DE MODAL
   ========================================================================== */

/**
 * Abre o modal com um formulário.
 * @param {string} type - 'cliente' | 'servico' | 'barbeiro' | 'agendamento' | 'bloquear'
 * @param {object} [data] - dados do registro (quando for edição)
 */
function openModal(type, data) {
    const overlay = document.getElementById('modalOverlay');
    const content = document.getElementById('modalContent');
    overlay.classList.add('open');

    switch (type) {
        case 'cliente':
            content.innerHTML = renderClienteForm(data);
            break;
        case 'servico':
            content.innerHTML = renderServicoForm(data);
            break;
        case 'barbeiro':
            content.innerHTML = renderBarbeiroForm(data);
            break;
        case 'agendamento':
            content.innerHTML = renderAgendamentoForm(data);
            break;
        case 'bloquear':
            content.innerHTML = renderBloquearForm();
            break;
        default:
            content.innerHTML = '<p>Formulário não encontrado.</p>';
    }
}

/** Abre o modal com um HTML qualquer. */
function openModalWithContent(html) {
    const overlay = document.getElementById('modalOverlay');
    const content = document.getElementById('modalContent');
    content.innerHTML = html;
    overlay.classList.add('open');
}

/** Fecha o modal. */
function closeModal() {
    document.getElementById('modalOverlay').classList.remove('open');
}

// Clicar fora da janela (no fundo escuro) fecha o modal
document.getElementById('modalOverlay').addEventListener('click', function(e) {
    if (e.target === this) closeModal();
});

// ----- Atalhos para abrir o modal em modo edição -----
function openEditCliente(id) {
    const c = getClient(id);
    if (c) openModal('cliente', c);
}

function openEditServico(id) {
    const s = DB.services.find(se => se.id === id);
    if (s) openModal('servico', s);
}

function openEditBarber(id) {
    const b = getBarber(id);
    if (b) openModal('barbeiro', b);
}

/** Abre o modal com os detalhes de um agendamento e as ações possíveis. */
function openEditAppointment(id) {
    const a = DB.appointments.find(ap => ap.id === id);
    if (!a) return;
    const cl = getClient(a.clienteId);
    const sv = getService(a.servicoId);
    const br = getBarber(a.barbeiroId);
    const html = `
        <div class="space-y-4">
            <h3 class="font-bold text-lg">Detalhes do Agendamento</h3>
            <div class="space-y-2">
                <p><span class="text-[var(--text-muted)]">Cliente:</span> ${cl ? cl.nome : '—'}</p>
                <p><span class="text-[var(--text-muted)]">Serviço:</span> ${sv ? sv.nome : '—'}</p>
                <p><span class="text-[var(--text-muted)]">Barbeiro:</span> ${br ? br.nome : '—'}</p>
                <p><span class="text-[var(--text-muted)]">Data:</span> ${formatDate(a.data)} às ${a.hora}</p>
                <p><span class="text-[var(--text-muted)]">Valor:</span> ${formatCurrency(a.valor)}</p>
                <p><span class="text-[var(--text-muted)]">Status:</span> <span class="badge ${a.status === 'finalizado' ? 'badge-success' : a.status === 'cancelado' ? 'badge-danger' : 'badge-info'}">${a.status}</span></p>
                ${a.observacoes ? `<p><span class="text-[var(--text-muted)]">Obs:</span> ${a.observacoes}</p>` : ''}
            </div>
            <div class="flex gap-3 pt-2">
                ${a.status !== 'finalizado' && a.status !== 'cancelado' ? `
                <button onclick="finalizeAppointment('${a.id}')" class="btn btn-success btn-sm"><i class="fas fa-check"></i> Finalizar</button>
                <button onclick="cancelAppointment('${a.id}')" class="btn btn-danger btn-sm"><i class="fas fa-times"></i> Cancelar</button>
                ` : ''}
                ${a.status !== 'cancelado' ? `
                <button onclick="sendWhatsAppConfirm('${a.id}')" class="btn btn-primary btn-sm"><i class="fab fa-whatsapp"></i> WhatsApp</button>
                ` : ''}
                <button onclick="closeModal()" class="btn btn-secondary btn-sm">Fechar</button>
            </div>
        </div>
    `;
    openModalWithContent(html);
}

/** Marca o agendamento como finalizado e registra o pagamento. */
function finalizeAppointment(id) {
    const a = DB.appointments.find(ap => ap.id === id);
    if (a) {
        a.status = 'finalizado';
        // Cria o registro de pagamento caso ainda não exista
        if (!DB.payments.some(p => p.appointmentId === id)) {
            DB.payments.push({
                id: generateId(),
                appointmentId: id,
                valor: a.valor,
                formaPagamento: a.formaPagamento || 'dinheiro',
                data: today(),
                status: 'confirmado'
            });
        }
        saveData();
        showToast('Atendimento finalizado com sucesso!', 'success');
        closeModal();
        renderCurrentPage();
    }
}

/** Cancela um agendamento (pede o motivo) e registra no histórico. */
function cancelAppointment(id) {
    const a = DB.appointments.find(ap => ap.id === id);
    if (a && a.status !== 'cancelado') {
        const motivo = prompt('Motivo do cancelamento:');
        if (motivo === null) return;
        a.status = 'cancelado';
        DB.cancellations.push({
            id: generateId(),
            appointmentId: id,
            motivo: motivo || 'Cancelado pelo operador',
            data: today(),
            por: 'barbearia'
        });
        saveData();
        showToast('Agendamento cancelado.', 'info');
        closeModal();
        renderCurrentPage();
    }
}

/** Abre o WhatsApp com a mensagem de confirmação do agendamento. */
function sendWhatsAppConfirm(id) {
    const a = DB.appointments.find(ap => ap.id === id);
    if (!a) return;
    const cl = getClient(a.clienteId);
    const sv = getService(a.servicoId);
    const br = getBarber(a.barbeiroId);
    if (!cl) return;
    const msg = encodeURIComponent(
        `Olá ${cl.nome}! Seu agendamento na ${DB.settings.barberShop.nome} está confirmado! ✂️\n\n` +
        `📅 Data: ${formatDate(a.data)}\n` +
        `⏰ Horário: ${a.hora}\n` +
        `💈 Serviço: ${sv ? sv.nome : '—'}\n` +
        `👤 Barbeiro: ${br ? br.nome : '—'}\n` +
        `💰 Valor: ${formatCurrency(a.valor)}\n\n` +
        `Qualquer dúvida, estamos à disposição! 🙌`
    );
    const whats = DB.settings.barberShop.whatsapp || '5511999999999';
    window.open(`https://wa.me/${whats}?text=${msg}`, '_blank');
}


/* ==========================================================================
   05. FORMULÁRIOS (exibidos dentro do modal)
   ========================================================================== */

// ----- Cliente -----

/** Formulário de cliente (novo ou edição). */
function renderClienteForm(data) {
    const isEdit = !!data;
    const c = data || { id: '', nome: '', telefone: '', email: '', observacoes: '', preferencias: '', ativo: true };
    return `
        <h3 class="font-bold text-lg mb-4">${isEdit ? 'Editar' : 'Novo'} Cliente</h3>
        <form onsubmit="${isEdit ? `saveClienteEdit(event,'${c.id}')` : 'saveCliente(event)'}" class="space-y-4">
            <div>
                <label class="form-label">Nome *</label>
                <input type="text" class="form-input" name="nome" value="${c.nome}" required>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="form-label">Telefone</label>
                    <input type="text" class="form-input" name="telefone" value="${c.telefone || ''}">
                </div>
                <div>
                    <label class="form-label">Email</label>
                    <input type="email" class="form-input" name="email" value="${c.email || ''}">
                </div>
            </div>
            <div>
                <label class="form-label">Preferências</label>
                <input type="text" class="form-input" name="preferencias" value="${c.preferencias || ''}">
            </div>
            <div>
                <label class="form-label">Observações</label>
                <textarea class="form-input" name="observacoes" rows="2">${c.observacoes || ''}</textarea>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> ${isEdit ? 'Salvar' : 'Cadastrar'}</button>
                <button type="button" onclick="closeModal()" class="btn btn-secondary">Cancelar</button>
            </div>
        </form>
    `;
}

/** Cadastra um novo cliente. */
function saveCliente(e) {
    e.preventDefault();
    const data = new FormData(e.target);
    const novo = {
        id: generateId(),
        nome: data.get('nome'),
        telefone: data.get('telefone') || '',
        email: data.get('email') || '',
        dataCadastro: today(),
        ultimaVisita: '',
        observacoes: data.get('observacoes') || '',
        ativo: true,
        preferencias: data.get('preferencias') || ''
    };
    DB.clients.push(novo);
    saveData();
    showToast('Cliente cadastrado com sucesso!', 'success');
    closeModal();
    renderCurrentPage();
}

/** Salva a edição de um cliente existente. */
function saveClienteEdit(e, id) {
    e.preventDefault();
    const data = new FormData(e.target);
    const c = DB.clients.find(cl => cl.id === id);
    if (c) {
        c.nome = data.get('nome');
        c.telefone = data.get('telefone') || '';
        c.email = data.get('email') || '';
        c.preferencias = data.get('preferencias') || '';
        c.observacoes = data.get('observacoes') || '';
        saveData();
        showToast('Cliente atualizado!', 'success');
        closeModal();
        renderCurrentPage();
    }
}

// ----- Serviço -----

/** Formulário de serviço (novo ou edição). */
function renderServicoForm(data) {
    const isEdit = !!data;
    const s = data || { id: '', nome: '', preco: '', duracao: '', descricao: '', ativo: true };
    return `
        <h3 class="font-bold text-lg mb-4">${isEdit ? 'Editar' : 'Novo'} Serviço</h3>
        <form onsubmit="${isEdit ? `saveServicoEdit(event,'${s.id}')` : 'saveServico(event)'}" class="space-y-4">
            <div>
                <label class="form-label">Nome do Serviço *</label>
                <input type="text" class="form-input" name="nome" value="${s.nome}" required>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="form-label">Preço (R$) *</label>
                    <input type="number" class="form-input" name="preco" value="${s.preco}" step="0.01" min="0" required>
                </div>
                <div>
                    <label class="form-label">Duração (min) *</label>
                    <input type="number" class="form-input" name="duracao" value="${s.duracao}" min="5" max="240" required>
                </div>
            </div>
            <div>
                <label class="form-label">Descrição</label>
                <textarea class="form-input" name="descricao" rows="2">${s.descricao || ''}</textarea>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> ${isEdit ? 'Salvar' : 'Criar'}</button>
                <button type="button" onclick="closeModal()" class="btn btn-secondary">Cancelar</button>
            </div>
        </form>
    `;
}

/** Cria um novo serviço. */
function saveServico(e) {
    e.preventDefault();
    const data = new FormData(e.target);
    const novo = {
        id: generateId(),
        nome: data.get('nome'),
        preco: parseFloat(data.get('preco')) || 0,
        duracao: parseInt(data.get('duracao')) || 30,
        descricao: data.get('descricao') || '',
        ativo: true
    };
    DB.services.push(novo);
    saveData();
    showToast('Serviço criado com sucesso!', 'success');
    closeModal();
    renderCurrentPage();
}

/** Salva a edição de um serviço existente. */
function saveServicoEdit(e, id) {
    e.preventDefault();
    const data = new FormData(e.target);
    const s = DB.services.find(se => se.id === id);
    if (s) {
        s.nome = data.get('nome');
        s.preco = parseFloat(data.get('preco')) || 0;
        s.duracao = parseInt(data.get('duracao')) || 30;
        s.descricao = data.get('descricao') || '';
        saveData();
        showToast('Serviço atualizado!', 'success');
        closeModal();
        renderCurrentPage();
    }
}

// ----- Barbeiro -----

/** Formulário de barbeiro (novo ou edição). */
function renderBarbeiroForm(data) {
    const isEdit = !!data;
    const b = data || { id: '', nome: '', foto: '', ativo: true };
    return `
        <h3 class="font-bold text-lg mb-4">${isEdit ? 'Editar' : 'Novo'} Barbeiro</h3>
        <form onsubmit="${isEdit ? `saveBarbeiroEdit(event,'${b.id}')` : 'saveBarbeiro(event)'}" class="space-y-4">
            <div>
                <label class="form-label">Nome *</label>
                <input type="text" class="form-input" name="nome" value="${b.nome}" required>
            </div>
            <div>
                <label class="form-label">URL da Foto</label>
                <input type="text" class="form-input" name="foto" value="${b.foto || ''}" placeholder="https://picsum.photos/200?random=...">
            </div>
            <div class="flex gap-3 pt-2">
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> ${isEdit ? 'Salvar' : 'Adicionar'}</button>
                <button type="button" onclick="closeModal()" class="btn btn-secondary">Cancelar</button>
            </div>
        </form>
    `;
}

/** Adiciona um novo barbeiro. */
function saveBarbeiro(e) {
    e.preventDefault();
    const data = new FormData(e.target);
    const novo = {
        id: generateId(),
        nome: data.get('nome'),
        foto: data.get('foto') || `https://picsum.photos/200?random=${Math.floor(Math.random() * 1000)}`,
        ativo: true
    };
    DB.barbers.push(novo);
    saveData();
    showToast('Barbeiro adicionado!', 'success');
    closeModal();
    renderCurrentPage();
}

/** Salva a edição de um barbeiro existente. */
function saveBarbeiroEdit(e, id) {
    e.preventDefault();
    const data = new FormData(e.target);
    const b = DB.barbers.find(bar => bar.id === id);
    if (b) {
        b.nome = data.get('nome');
        b.foto = data.get('foto') || b.foto;
        saveData();
        showToast('Barbeiro atualizado!', 'success');
        closeModal();
        renderCurrentPage();
    }
}

// ----- Agendamento rápido (modal) -----

/** Formulário simplificado de agendamento, usado dentro do modal. */
function renderAgendamentoForm(data) {
    const clientes = DB.clients.filter(c => c.ativo);
    const servicos = DB.services.filter(s => s.ativo);
    const barbeiros = DB.barbers.filter(b => b.ativo);
    const hoje = today();
    return `
        <h3 class="font-bold text-lg mb-4">Novo Agendamento Rápido</h3>
        <form onsubmit="submitAgendamentoModal(event)" class="space-y-4">
            <div>
                <label class="form-label">Cliente *</label>
                <select class="form-select" name="clienteId" required>
                    <option value="">Selecione</option>
                    ${clientes.map(c => `<option value="${c.id}">${c.nome}</option>`).join('')}
                </select>
            </div>
            <div>
                <label class="form-label">Serviço *</label>
                <select class="form-select" name="servicoId" required>
                    <option value="">Selecione</option>
                    ${servicos.map(s => `<option value="${s.id}">${s.nome} - ${formatCurrency(s.preco)}</option>`).join('')}
                </select>
            </div>
            <div>
                <label class="form-label">Barbeiro *</label>
                <select class="form-select" name="barbeiroId" required>
                    <option value="">Selecione</option>
                    ${barbeiros.map(b => `<option value="${b.id}">${b.nome}</option>`).join('')}
                </select>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="form-label">Data *</label>
                    <input type="date" class="form-input" name="data" value="${hoje}" min="${hoje}" required>
                </div>
                <div>
                    <label class="form-label">Horário *</label>
                    <select class="form-select" name="hora" required>
                        <option value="">Hora</option>
                        ${gerarHorarios().map(h => `<option value="${h}">${h}</option>`).join('')}
                    </select>
                </div>
            </div>
            <div class="flex gap-3 pt-2">
                <button type="submit" class="btn btn-primary"><i class="fas fa-check"></i> Agendar</button>
                <button type="button" onclick="closeModal()" class="btn btn-secondary">Cancelar</button>
            </div>
        </form>
    `;
}

/** Valida e salva o agendamento rápido feito pelo modal. */
function submitAgendamentoModal(e) {
    e.preventDefault();
    const data = new FormData(e.target);
    const clienteId = data.get('clienteId');
    const servicoId = data.get('servicoId');
    const barbeiroId = data.get('barbeiroId');
    const dt = data.get('data');
    const hora = data.get('hora');
    const servico = getService(servicoId);

    if (!clienteId || !servicoId || !barbeiroId || !dt || !hora) {
        showToast('Preencha todos os campos.', 'error');
        return;
    }
    // Impede dois agendamentos no mesmo horário para o mesmo barbeiro
    const conflito = DB.appointments.some(a => a.data === dt && a.hora === hora && a.barbeiroId === barbeiroId && a.status !== 'cancelado');
    if (conflito) {
        showToast('Horário já agendado para este barbeiro.', 'error');
        return;
    }
    const novo = {
        id: generateId(),
        clienteId,
        servicoId,
        barbeiroId,
        data: dt,
        hora,
        status: 'agendado',
        valor: servico ? servico.preco : 0,
        formaPagamento: '',
        observacoes: ''
    };
    DB.appointments.push(novo);
    const cl = getClient(clienteId);
    if (cl) cl.ultimaVisita = dt;
    saveData();
    showToast('Agendamento criado!', 'success');
    closeModal();
    renderCurrentPage();
}

// ----- Bloqueio de horário -----

/** Formulário para bloquear horários (folgas, reuniões, etc.). */
function renderBloquearForm() {
    return `
        <h3 class="font-bold text-lg mb-4">Bloquear Horário</h3>
        <form onsubmit="submitBloquear(event)" class="space-y-4">
            <div>
                <label class="form-label">Barbeiro</label>
                <select class="form-select" name="barbeiroId" required>
                    <option value="">Todos</option>
                    ${DB.barbers.filter(b => b.ativo).map(b => `<option value="${b.id}">${b.nome}</option>`).join('')}
                </select>
            </div>
            <div>
                <label class="form-label">Data *</label>
                <input type="date" class="form-input" name="data" value="${today()}" min="${today()}" required>
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="form-label">De</label>
                    <input type="time" class="form-input" name="inicio" value="08:00" required>
                </div>
                <div>
                    <label class="form-label">Até</label>
                    <input type="time" class="form-input" name="fim" value="12:00" required>
                </div>
            </div>
            <div>
                <label class="form-label">Motivo</label>
                <input type="text" class="form-input" name="motivo" placeholder="Ex: Folga, reunião">
            </div>
            <div class="flex gap-3 pt-2">
                <button type="submit" class="btn btn-primary"><i class="fas fa-lock"></i> Bloquear</button>
                <button type="button" onclick="closeModal()" class="btn btn-secondary">Cancelar</button>
            </div>
        </form>
    `;
}

/** Salva o bloqueio de horário. */
function submitBloquear(e) {
    e.preventDefault();
    const data = new FormData(e.target);
    DB.settings.blockedTimes.push({
        id: generateId(),
        barbeiroId: data.get('barbeiroId') || '',
        data: data.get('data'),
        inicio: data.get('inicio'),
        fim: data.get('fim'),
        motivo: data.get('motivo') || 'Bloqueado'
    });
    saveData();
    showToast('Horário bloqueado com sucesso!', 'success');
    closeModal();
    renderCurrentPage();
}


/* ==========================================================================
   06. EXPORTAR / IMPORTAR / RESETAR DADOS
   ========================================================================== */

/** Baixa todos os dados em um arquivo JSON (backup). */
function exportData() {
    const blob = new Blob([JSON.stringify(DB, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `barberflow_dados_${today()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showToast('Dados exportados com sucesso!', 'success');
}

/** Importa dados de um arquivo JSON (exportado anteriormente). */
function importData() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (ev) => {
            try {
                const imported = JSON.parse(ev.target.result);
                // Validação mínima: precisa ter os blocos principais
                if (imported.barbers && imported.services && imported.clients && imported.appointments) {
                    DB = imported;
                    saveData();
                    showToast('Dados importados com sucesso!', 'success');
                    renderCurrentPage();
                } else {
                    showToast('Arquivo inválido. Verifique o formato.', 'error');
                }
            } catch (err) {
                showToast('Erro ao ler arquivo: ' + err.message, 'error');
            }
        };
        reader.readAsText(file);
    };
    input.click();
}

/** Restaura os dados de exemplo (apaga tudo, com confirmação). */
function resetData() {
    if (confirm('Tem certeza? Todos os dados serão perdidos!')) {
        DB = getDefaultData();
        saveData();
        showToast('Dados resetados para o padrão.', 'info');
        renderCurrentPage();
    }
}


/* ==========================================================================
   07. NAVEGAÇÃO
   ========================================================================== */

/** Vai para uma página: atualiza o menu, desenha a página e guarda a última visitada. */
function navigate(pageId) {
    currentPage = pageId;
    // Atualiza o item ativo da sidebar
    document.querySelectorAll('.nav-item').forEach(el => {
        el.classList.toggle('active', el.dataset.nav === pageId);
    });
    renderPage(pageId);
    // Fecha a sidebar no mobile
    closeSidebar();
    // Lembra a última página aberta
    localStorage.setItem('barberflow_lastpage', pageId);
}

/** Redesenha a página atual (usado após salvar/editar algo). */
function renderCurrentPage() {
    renderPage(currentPage);
    // Mantém o item ativo do menu
    document.querySelectorAll('.nav-item').forEach(el => {
        el.classList.toggle('active', el.dataset.nav === currentPage);
    });
}

/** Fecha a sidebar (mobile). */
function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sidebarOverlay').classList.add('hidden');
}


/* ==========================================================================
   08. EVENTOS (delegação de cliques)
   Um único listener no document trata menu, sidebar, modal e links âncora.
   ========================================================================== */

document.addEventListener('click', function(e) {
    // Cliques nos itens do menu
    const navLink = e.target.closest('[data-nav]');
    if (navLink) {
        e.preventDefault();
        navigate(navLink.dataset.nav);
        return;
    }

    // Botão que abre/fecha a sidebar (mobile)
    const toggle = e.target.closest('#sidebarToggle');
    if (toggle) {
        e.preventDefault();
        document.getElementById('sidebar').classList.toggle('open');
        document.getElementById('sidebarOverlay').classList.toggle('hidden');
        return;
    }

    // Clique no fundo escuro da sidebar fecha o menu
    const overlay = e.target.closest('#sidebarOverlay');
    if (overlay) {
        closeSidebar();
        return;
    }

    // Botão de fechar do modal
    const closeBtn = e.target.closest('.modal-close');
    if (closeBtn) {
        closeModal();
    }

    // Rolagem suave para links âncora (#...)
    const anchor = e.target.closest('a[href^="#"]');
    if (anchor) {
        e.preventDefault();
        const target = document.querySelector(anchor.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth' });
        }
    }
});

// Sincroniza os dados quando outra aba do navegador altera o LocalStorage
window.addEventListener('storage', function(e) {
    if (e.key === STORAGE_KEY) {
        DB = loadData();
        renderCurrentPage();
        showToast('Dados atualizados de outra aba.', 'info');
    }
});


/* ==========================================================================
   09. INICIALIZAÇÃO
   ========================================================================== */

function init() {
    // Desenha o menu lateral
    document.getElementById('navContainer').innerHTML = renderNav();

    // Abre a última página visitada (ou o Dashboard)
    const lastPage = localStorage.getItem('barberflow_lastpage') || 'dashboard';
    navigate(lastPage);
}

// Inicia o sistema
init();
